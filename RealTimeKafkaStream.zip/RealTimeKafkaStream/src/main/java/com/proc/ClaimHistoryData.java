package com.proc;

import com.hcsc.health.claim.v3.InsuranceClaim;

import java.io.Serializable;

public class ClaimHistoryData implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -6638898552517798359L;

    // Fields to Identify processed claims
    private String clmId;
    private String dcn;

    // Holds Claim Information from AOM
    private InsuranceClaim claims;

    // Fields populated from Failed Claims Error Table
    private String corpEntityCd;
    private String adjstmtNbr;
    private String extrctStaCd;
    private String clmStaEffTs;
    private String lstStaUpdTs;
    private String extrctFailrCnt;
    private String audTs;
    private String audProc;
    private String audUsr;
    private boolean isClaimExtracted;
    private String aomExtractStatus;

    public boolean isClaimExtracted() {
        return isClaimExtracted;
    }

    public void setClaimExtracted(boolean isClaimExtracted) {
        this.isClaimExtracted = isClaimExtracted;
    }

    public InsuranceClaim getClaims() {
        return claims;
    }

    public void setClaims(InsuranceClaim claims) {
        this.claims = claims;
    }

    public String getDcn() {
        return dcn;
    }

    public void setDcn(String dcn) {
        this.dcn = dcn;
    }

    public String getCorpEntityCd() {
        return corpEntityCd;
    }

    public void setCorpEntityCd(String corpEntityCd) {
        this.corpEntityCd = corpEntityCd;
    }

    public String getClmId() {
        return clmId;
    }

    public void setClmId(String clmId) {
        this.clmId = clmId;
    }

    public String getAdjstmtNbr() {
        return adjstmtNbr;
    }

    public void setAdjstmtNbr(String adjstmtNbr) {
        this.adjstmtNbr = adjstmtNbr;
    }

    public String getExtrctStaCd() {
        return extrctStaCd;
    }

    public void setExtrctStaCd(String extrctStaCd) {
        this.extrctStaCd = extrctStaCd;
    }

    public String getClmStaEffTs() {
        return clmStaEffTs;
    }

    public void setClmStaEffTs(String clmStaEffTs) {
        this.clmStaEffTs = clmStaEffTs;
    }

    public String getLstStaUpdTs() {
        return lstStaUpdTs;
    }

    public void setLstStaUpdTs(String lstStaUpdTs) {
        this.lstStaUpdTs = lstStaUpdTs;
    }

    public String getExtrctFailrCnt() {
        return extrctFailrCnt;
    }

    public void setExtrctFailrCnt(String extrctFailrCnt) {
        this.extrctFailrCnt = extrctFailrCnt;
    }

    public String getAudTs() {
        return audTs;
    }

    public void setAudTs(String audTs) {
        this.audTs = audTs;
    }

    public String getAudProc() {
        return audProc;
    }

    public void setAudProc(String audProc) {
        this.audProc = audProc;
    }

    public String getAudUsr() {
        return audUsr;
    }

    public void setAudUsr(String audUsr) {
        this.audUsr = audUsr;
    }

    public String getAomExtractStatus() {
        return aomExtractStatus;
    }

    public void setAomExtractStatus(String aomExtractStatus) {
        this.aomExtractStatus = aomExtractStatus;
    }

}
