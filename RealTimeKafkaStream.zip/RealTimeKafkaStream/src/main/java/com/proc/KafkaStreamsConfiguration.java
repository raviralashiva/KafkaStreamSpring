package com.proc;


import java.util.*;

import com.hcsc.aom2.readwrite.cts3.service.Cts3ReadService;
import com.hcsc.health.claim.v3.InsuranceClaim;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.Consumed;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.KeyValueMapper;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.Reducer;
import org.apache.kafka.streams.state.KeyValueStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerde;




import lombok.Data;

@Configuration
@EnableKafka
@EnableKafkaStreams
public class KafkaStreamsConfiguration {

    @Autowired private KafkaProperties kafkaProperties;

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public StreamsConfig kStreamsConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test-streams");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrapServers());
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(JsonDeserializer.DEFAULT_KEY_TYPE, String.class);
        props.put(JsonDeserializer.DEFAULT_VALUE_TYPE, String.class);
        return new StreamsConfig(props);
    }



    // Cts3ReadService cts3ReadService ;
    ApplicationContext context ;
    @Autowired
    public void context(ApplicationContext context) {
        this.context = context;
    }

    static  ClaimHistoryData parseJson(String input) throws Exception {

        ClaimHistoryData claimHistoryData = new ClaimHistoryData();

        System.out.println("Inside parse json function");
        JSONObject jsonobj = (JSONObject) JSONValue.parseWithException(input);
        JSONObject cdr = (JSONObject) jsonobj.get("ClaimDetailRecord");
        JSONObject cl = (JSONObject) cdr.get("ClaimLevel");

        String dcn = (String) cl.get("DCN");
        claimHistoryData.setDcn(dcn);
        String ctype = (String) cl.get("claimType");
        claimHistoryData.setCorpEntityCd(ctype);
        String wrklistStatus =  (String) cl.get("worklistStatus");
        claimHistoryData.setAdjstmtNbr(wrklistStatus);

        System.out.println("Value of DCN: " + dcn);
        System.out.println("Value of claim type: " + ctype);
        System.out.println("Value of Worklist Status " + wrklistStatus);

        return claimHistoryData ;
    }

    public void FurtherFind(ClaimHistoryData result){

        long stTime = Calendar.getInstance().getTimeInMillis();

        //Cts3ReadService cts3ReadServiceMain = (Cts3ReadService)context.getBean("Cts3ReadService");
        String dcn = result.getDcn();
        String corpEntityCd = result.getCorpEntityCd() ;
        Short adjustmentNbr = Short.parseShort(result.getAdjstmtNbr());
        Cts3ReadService cts3ReadServiceMain = (Cts3ReadService)context.getBean("Cts3ReadService");

        try {
            InsuranceClaim insClaim =  cts3ReadServiceMain.find(dcn, corpEntityCd,adjustmentNbr);
            long endTime = Calendar.getInstance().getTimeInMillis();
            System.out.println(" TIME # " + (endTime - stTime));
            if(insClaim!=null){
                //System.out.println("Claim with CLM_ID {} Adjustment Nbr {} and DCN {} successfully read",  insClaim.getClaimHeader().getClaimIdentifier(),adjustmentNbr, dcn);
                System.out.println("Successfully extracted Insurance Claim") ;
                result.setClaimExtracted(true);
            }
            else {
                System.out.println("FAILED to read claim with DCN ");

                result.setAomExtractStatus("404");
            }
            result.setClaims(insClaim);
        }
        catch(RuntimeException e){
            //LOG.debug("FAILED to retrieve claim with DCN {} and CORP_ENT_CD",  dcn, corpEntityCd);
            System.out.println("Exception occured");
            e.printStackTrace();

            result.setAomExtractStatus("503");
        }
    }


    @Bean

    public KStream<String, String> startProcessing( StreamsBuilder builder) {

        final KStream<String, String> strm = builder.stream("input-stream", Consumed.with(Serdes.String(), Serdes.String()));
        strm.map((key, value) -> { // do something with each msg, square the values in our case
            System.out.println("VALUE OBTAINED IS: " + value);

            try {

                FurtherFind(parseJson(value));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return KeyValue.pair(key, value );

        });
        return strm;
    }





}

